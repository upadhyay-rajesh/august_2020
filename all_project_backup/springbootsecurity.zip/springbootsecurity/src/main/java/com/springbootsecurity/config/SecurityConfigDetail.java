package com.springbootsecurity.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfigDetail extends WebSecurityConfigurerAdapter {
	
	//authentication
	public void configure(AuthenticationManagerBuilder auth)throws Exception {
		auth.inMemoryAuthentication().withUser("rajesh").password("upadhyay").roles("USER");
		auth.inMemoryAuthentication().withUser("rajesh1").password("upadhyay1").roles("ADMIN");
		auth.inMemoryAuthentication().withUser("rajesh2").password("upadhyay2").roles("ADMIN");
	}
	
	//authorization
	public void configure(HttpSecurity http) throws Exception{
		http.antMatcher("/**").authorizeRequests().anyRequest().hasRole("USER")
		.and().formLogin().loginPage("/login.jsp")
		.failureUrl("/loginfail.jsp").loginProcessingUrl("/logincontroller")
		.permitAll().and().logout()
		.logoutSuccessUrl("/login.jsp");
	}
	
}
