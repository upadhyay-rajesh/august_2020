package com.springbootsecurity.controller;

import org.springframework.stereotype.Controller;

@Controller
public class EmployeeController {
	
	

}
