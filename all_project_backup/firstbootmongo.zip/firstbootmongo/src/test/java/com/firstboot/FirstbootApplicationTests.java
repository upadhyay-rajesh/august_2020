package com.firstboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
