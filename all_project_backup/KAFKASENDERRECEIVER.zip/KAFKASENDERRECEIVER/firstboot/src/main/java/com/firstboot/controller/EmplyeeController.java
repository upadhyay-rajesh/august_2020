package com.firstboot.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.firstboot.dao.EmployeeDAOInterface;
import com.firstboot.dao.EmployeeDAOInterfaceMongo;
import com.firstboot.entity.Employee;
import com.firstboot.entity.EmployeeMongo;
import com.firstboot.utility.Sender;
import com.netflix.hystrix.contrib.javanica.annotation.DefaultProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@DefaultProperties(defaultFallback = "mymethod")
public class EmplyeeController {
	
	String mymethod() {
		return "service is down";
	}
	
	@Autowired
	private EmployeeDAOInterface empdao;
	
	@RequestMapping("allEmployee")
	@HystrixCommand
	public List<Employee> displayAllEmployee(){
		List<Employee> el=new ArrayList<Employee>();
		Employee e1=new Employee();
		e1.setName("Rajesh");
		e1.setPassword("abcd");
		e1.setEmail("abc@yahoo.com");
		e1.setAddress("Bangalore");
		
		el.add(e1);
		return el;
	}
	
	@RequestMapping("allEmployeejdbc")
	@HystrixCommand(fallbackMethod = "userDefinedMethod")
	public List<Employee> displayAllEmployeejdbc(){
		List<Employee> el=empdao.getdaoall();
		if(el.size()>0) {
			throw new ArithmeticException();
		}
		return el;
	}
	public List<Employee> userDefinedMethod(){
		List<Employee> el=new ArrayList<Employee>();
		Employee e1=new Employee();
		e1.setName("default_name");
		e1.setPassword("abcd");
		e1.setEmail("default@yahoo.com");
		e1.setAddress("Chennai");
		el.add(e1);
		return el;
	}
	
	@RequestMapping("allEmployeejpa")
	@HystrixCommand
	public List<Employee> displayAllEmployeejpa(){
		List<Employee> el=empdao.getdaoalljpa();
		
		return el;
	}
	
	@Autowired
	private EmployeeDAOInterfaceMongo empmongo;
	
	@RequestMapping("allEmployeemongo")
	@HystrixCommand
	public List<EmployeeMongo> displayAllEmployeemongo(){
		List<EmployeeMongo> el=empmongo.findAll();
		
		return el;
	}

	@PostMapping("createEmployeemongo")
	@HystrixCommand
	public EmployeeMongo createAllEmployeemongo(@RequestBody EmployeeMongo emp){
		return empmongo.save(emp);
	}
	
	@Autowired
	private Sender ss;
	
	@RequestMapping("sendmessage")
	public String sendmessage(){
		ss.sendmessage("mytopic", "hello i am message comming from employeeservice");
		
		return "message sent successfully";
	}
	
}


























