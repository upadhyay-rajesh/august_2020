package com.consumer.controller;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class ConsumerController {
	public void accessEmployee() {
		RestTemplate client=new RestTemplate();
		ResponseEntity<String> result=null;
		result=client.exchange("http://localhost:10000/allEmployeejpa",HttpMethod.GET,createHeader(),String.class);
		
		System.out.println(result.getBody());
	}
	
	public static HttpEntity<?> createHeader(){
		HttpHeaders h=new HttpHeaders();
		h.set("Accept",MediaType.APPLICATION_JSON_VALUE);
		
		return new HttpEntity<>(h);
	}
}
