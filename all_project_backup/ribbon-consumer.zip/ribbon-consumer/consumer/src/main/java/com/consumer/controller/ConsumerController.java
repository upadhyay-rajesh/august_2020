package com.consumer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class ConsumerController {
	
	//@Autowired
	//private DiscoveryClient dc;
	
	
	@Autowired
	private LoadBalancerClient lbc;
	
	
	public void accessEmployee() {
		
		//List<ServiceInstance> s=dc.getInstances("FIRST-PRODUCER");
		//ServiceInstance s1=s.get(0);
		
		ServiceInstance s2=lbc.choose("FIRST-PRODUCER");
		
		String url=s2.getUri().toString();
		url=url+"/allEmployeejpa";
		
		
		RestTemplate client=new RestTemplate();
		ResponseEntity<String> result=null;
		result=client.exchange(url,HttpMethod.GET,createHeader(),String.class);
		
		System.out.println(result.getBody());
	}
	
	public static HttpEntity<?> createHeader(){
		HttpHeaders h=new HttpHeaders();
		h.set("Accept",MediaType.APPLICATION_JSON_VALUE);
		
		return new HttpEntity<>(h);
	}
}
