package com.consumer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class ConsumerController {
	
	@Autowired
	private DiscoveryClient dc;
	
	
	public void accessEmployee() {
		
		List<ServiceInstance> s=dc.getInstances("FIRST-PRODUCER");
		ServiceInstance s1=s.get(0);
		
		String u=s1.getUri().toString();
		u=u+"/allEmployeejpa";
		
		
		RestTemplate client=new RestTemplate();
		ResponseEntity<String> result=null;
		result=client.exchange(u,HttpMethod.GET,createHeader(),String.class);
		
		System.out.println(result.getBody());
	}
	
	public static HttpEntity<?> createHeader(){
		HttpHeaders h=new HttpHeaders();
		h.set("Accept",MediaType.APPLICATION_JSON_VALUE);
		
		return new HttpEntity<>(h);
	}
}
